<?php if(!empty($report_data)): 
    $g_total = ['sub'=>0, 'vat'=>0, 'sc'=>0, 'grand'=>0, 'disc'=>0, 'final'=>0];
?>

<div class="report-header-info" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; background: #fff; padding: 15px; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.05);">
    <div>
        <h3 style="margin:0; font-size:18px; color: #333;">
            <?php 
                $title = "Sales Report";
                if($_POST['report_type'] == 'item_wise') $title = "Item-wise Sales Report";
                if($_POST['report_type'] == 'category_wise') $title = "Category-wise Sales Report";
                if($_POST['report_type'] == 'service') $title = "Service-wise Performance Report";
                echo $title;
            ?>
        </h3>
        <p style="margin: 5px 0 0; font-size: 13px; color: #666;">
            📅 Period: <strong><?php echo esc_html($date_range); ?></strong>
        </p>
    </div>
    <div class="report-actions no-print"> <!-- no-print ক্লাসটি প্রিন্টে বাটন হাইড করবে -->
        <button onclick="printReport()" style="background: #3498db; color: #fff; border: none; padding: 8px 15px; border-radius: 4px; cursor: pointer;">🖨️ Print</button>
        <button id="btnExportExcel" style="background: #27ae60; color: #fff; border: none; padding: 8px 15px; border-radius: 4px; cursor: pointer;">📊 Excel</button>
        <button id="btnExportPDF" style="background: #e74c3c; color: #fff; border: none; padding: 8px 15px; border-radius: 4px; cursor: pointer;">📄 PDF</button>
    </div>
</div>


<div id="dynamic-print-header" style="display: none;">
    <?php include QRRS_PATH . 'templates/partials/header.php'; ?>
    <hr>
    <h2 style="text-align: center;"><?php echo $title; ?></h2>
    <p style="text-align: center;">Date Range: <?php echo $date_range; ?></p>
</div>

<div id="dynamic-print-footer" style="display: none;">
    <hr>
    <?php include QRRS_PATH . 'templates/partials/footer.php'; ?>
    <p style="text-align: center; font-size: 10px;">Generated on: <?php echo date('Y-m-d H:i:s'); ?></p>
</div>

<div id="report-print-area">
    <table class="qrrs-report-table" border="0" style="width: 100%; border-collapse: collapse; font-size: 16px;">
        <thead>
            <tr style="background: #2ecc71; color: white;">
                <th style="padding: 8px;">Inv #</th>
                <th style="padding: 8px;">Table / Mode</th>
                <th style="padding: 8px;">Order Type</th>
                <th style="padding: 8px;">Subtotal</th>
                <th style="padding: 8px;">VAT</th>
                <th style="padding: 8px;">S. Charge</th>
                <th style="padding: 8px;">Grand</th>
                <th style="padding: 8px;">Discount</th>
                <th style="padding: 8px;">Final Total</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach($report_data as $row): 
                // ডাইনামিক টাইপ ডিটেকশন
                $type = 'Dine-in';
                if($row->table_name == 'Take Out') $type = 'Takeaway';
                if($row->table_name == 'Delivery') $type = 'Delivery';

                $g_total['sub'] += $row->total_amount; $g_total['vat'] += $row->tax_amount;
                $g_total['sc'] += $row->service_charge; $g_total['grand'] += $row->grand_total;
                $g_total['disc'] += $row->discount_amount; $g_total['final'] += $row->final_total;
            ?>
            <tr style="border-bottom: 1px solid #eee;">
                <td>#<?php echo $row->id; ?></td>
                <td><?php echo $row->table_name; ?></td>
                <td><span style="padding: 2px 5px; border-radius: 3px; background: #eee; font-size: 10px;"><?php echo $type; ?></span></td>
                <td><?php echo number_format($row->total_amount, 2); ?></td>
                <td><?php echo number_format($row->tax_amount, 2); ?></td>
                <td><?php echo number_format($row->service_charge, 2); ?></td>
                <td><?php echo number_format($row->grand_total, 2); ?></td>
                <td><?php echo number_format($row->discount_amount, 2); ?></td>
                <td style="font-weight: bold;">৳ <?php echo number_format($row->final_total, 2); ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
        <tfoot style="background: #eee; font-weight: bold;">
            <tr>
                <td colspan="3" style="text-align: right;">GRAND TOTAL:</td>
                <td><?php echo number_format($g_total['sub'], 2); ?></td>
                <td><?php echo number_format($g_total['vat'], 2); ?></td>
                <td><?php echo number_format($g_total['sc'], 2); ?></td>
                <td><?php echo number_format($g_total['grand'], 2); ?></td>
                <td><?php echo number_format($g_total['disc'], 2); ?></td>
                <td style="color: #2ecc71;">৳ <?php echo number_format($g_total['final'], 2); ?></td>
            </tr>
        </tfoot>
    </table>
</div>

<?php endif; ?>


<style>
@media print {
    .visible-print { display: block !important; }
}
</style>