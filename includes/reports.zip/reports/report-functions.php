<?php
/**
 * Restaurant Reporting Functions - Full Logic
 */

// ১. কুইক সামারি (Today's Sales, Orders, Avg)
function get_qrrs_dashboard_summary() {
    global $wpdb;
    $table = $wpdb->prefix . 'qrrs_orders';
    $today = date('Y-m-d');
    return $wpdb->get_row($wpdb->prepare(
        "SELECT 
            IFNULL(SUM(final_total), 0) as sales,
            COUNT(id) as orders,
            IFNULL(AVG(final_total), 0) as avg_value
        FROM $table WHERE DATE(created_at) = %s", $today
    ));
}

// ২. মান্থলি সেলস ওভারভিউ (Month Overview)
function get_qrrs_monthly_chart_data() {
    global $wpdb;
    $table = $wpdb->prefix . 'qrrs_orders';
    return $wpdb->get_results("SELECT DATE(created_at) as date, SUM(final_total) as total FROM $table WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY) GROUP BY DATE(created_at) ORDER BY date ASC");
}

// ৩. স্টাফ সেলস পারফরম্যান্স (Staff Sales)
function get_qrrs_staff_sales() {
    global $wpdb;
    $orders = $wpdb->prefix . 'qrrs_orders';
    $users = $wpdb->users;
    return $wpdb->get_results("SELECT u.display_name, SUM(o.final_total) as total FROM $orders o JOIN $users u ON o.waiter_id = u.ID GROUP BY o.waiter_id ORDER BY total DESC");
}

// ৪. পেমেন্ট মেথড ডিস্ট্রিবিউশন
function get_qrrs_payment_summary() {
    global $wpdb;
    $table = $wpdb->prefix . 'qrrs_orders';
    return $wpdb->get_results("SELECT payment_method, COUNT(id) as count FROM $table GROUP BY payment_method");
}

// ৫. টপ সেলিং আইটেমস
function get_qrrs_top_items() {
    global $wpdb;
    $order_items = $wpdb->prefix . 'qrrs_order_items';
    return $wpdb->get_results("SELECT item_name, SUM(quantity) as qty FROM $order_items GROUP BY item_name ORDER BY qty DESC LIMIT 5");
}

// ৬. ভ্যাট ও সার্ভিস চার্জ
function get_qrrs_tax_summary() {
    global $wpdb;
    $table = $wpdb->prefix . 'qrrs_orders';
    return $wpdb->get_row("SELECT SUM(tax_amount) as total_vat, SUM(service_charge) as total_sc FROM $table");
}


// আইটেম ভিত্তিক সেলস রিপোর্ট ডেটা
function get_qrrs_item_wise_sales($start_date = '', $end_date = '', $category = 'all') {
    global $wpdb;
    $items_table = $wpdb->prefix . 'qrrs_order_items';
    $orders_table = $wpdb->prefix . 'qrrs_orders';
    
    $where = "WHERE 1=1";
    if(!empty($start_date) && !empty($end_date)) {
        $where .= $wpdb->prepare(" AND DATE(o.created_at) BETWEEN %s AND %s", $start_date, $end_date);
    }
    // যদি আপনার আইটেম টেবিলে ক্যাটাগরি কলাম থাকে তবে এখানে ক্যাটাগরি ফিল্টার যোগ করতে পারেন।

    return $wpdb->get_results("
        SELECT 
            item_name, 
            SUM(quantity) as total_qty, 
            SUM(price * quantity) as total_revenue,
            AVG(price) as avg_price
        FROM $items_table i
        JOIN $orders_table o ON i.order_id = o.id
        $where
        GROUP BY item_name 
        ORDER BY total_qty DESC
    ");
}



// ১. জেনারেল সেলস রিপোর্ট ফাংশন
function get_qrrs_general_sales($start, $end) {
    global $wpdb;
    $table = $wpdb->prefix . 'qrrs_orders';
    return $wpdb->get_results($wpdb->prepare(
        "SELECT id, table_name, total_amount, tax_amount, service_charge, grand_total, discount_amount, final_total, created_at 
        FROM $table WHERE DATE(created_at) BETWEEN %s AND %s ORDER BY id DESC", $start, $end
    ));
}

// ৪. সার্ভিস টাইপ রিপোর্ট ফাংশন (লজিক পরিবর্তন করা হয়েছে)
function get_qrrs_service_type_sales($start, $end) {
    global $wpdb;
    $table = $wpdb->prefix . 'qrrs_orders';
    return $wpdb->get_results($wpdb->prepare(
        "SELECT id, table_name, final_total, created_at, 
        (SELECT SUM(quantity) FROM {$wpdb->prefix}qrrs_order_items WHERE order_id = o.id) as total_items 
        FROM $table o WHERE DATE(created_at) BETWEEN %s AND %s", $start, $end
    ));
}