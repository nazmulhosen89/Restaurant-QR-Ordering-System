<?php
// report-main-dash.php
require_once(plugin_dir_path(__FILE__) . 'report-functions.php');

$summary = get_qrrs_dashboard_summary();
$monthly_chart = get_qrrs_monthly_chart_data();
$staff_data = get_qrrs_staff_sales();
$payment_data = get_qrrs_payment_summary();
$top_items = get_qrrs_top_items();
?>


<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<style>
    /* মেইন কন্টেইনার ফিক্স */
    .qrrs-report-main {
        max-width: 100%;
        overflow-x: hidden; /* লেফট-রাইট স্ক্রল বন্ধ করবে */
        background: #f8f9fa;
        padding: 15px;
        border-radius: 10px;
        font-family: 'Segoe UI', Tahoma, sans-serif;
        box-sizing: border-box;
    }

    /* রেসপনসিভ গ্রিড */
    .report-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(140px, 1fr));
        gap: 10px;
        margin-bottom: 25px;
        width: 100%;
    }

    .report-block {
        background: #fff;
        padding: 15px 5px;
        border-radius: 8px;
        border: 1px solid #ddd;
        text-align: center;
        cursor: pointer;
        font-weight: 600;
        font-size: 13px;
        color: #444;
        transition: 0.3s;
        box-sizing: border-box;
    }

    .report-block:hover {
        border-color: #2ecc71;
        background: #f9fffb;
    }

    /* কার্ড গ্রিড ফিক্স */
    .summary-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
        gap: 20px;
        margin-bottom: 25px;
    }

    .stat-card {
        background: #fff;
        padding: 20px;
        border-radius: 12px;
        box-shadow: 0 4px 10px rgba(0,0,0,0.05);
        text-align: center;
        border-bottom: 4px solid #eee;
        box-sizing: border-box;
    }

    .chart-container {
        background: #fff;
        padding: 20px;
        border-radius: 12px;
        box-shadow: 0 4px 10px rgba(0,0,0,0.05);
        margin-bottom: 25px;
        width: 100%;
        box-sizing: border-box;
        min-height: 300px; /* চার্টের জন্য নূন্যতম জায়গা */
        display: flex;
        flex-direction: column;
    }
    .chart-container canvas {
        flex-grow: 1;
        max-height: 350px; /* চার্ট খুব বেশি বড় হওয়া আটকাবে */
    }
    /* দুই কলামের লেআউট ফিক্স */
    .bottom-grid {
        display: grid;
        grid-template-columns: 1.5fr 1fr;
        gap: 20px;
        width: 100%;
    }

    /* মোবাইল ডিভাইসের জন্য ফিক্স */
    @media (max-width: 768px) {
        .bottom-grid {
            grid-template-columns: 1fr;
        }
    }
</style>

<!-- <div class="qrrs-report-main"> -->
    
    <!-- ১. টপ রিপোর্ট ব্লকস -->
    <!-- <div class="report-grid">
        <div class="report-block">Sales Report</div>
        <div class="report-block">Order Report</div>
        <div class="report-block">Item Performance</div>
        <div class="report-block">Kitchen/KOT</div>
        <div class="report-block">Staff Report</div>
        <div class="report-block">Payment Report</div>
        <div class="report-block">VAT/Service</div>
    </div> -->

    <!-- ২. টুডে সামারি কার্ডস -->
    <div class="summary-grid">
        <div class="stat-card" style="border-color:#2ecc71;">
            <small style="color:#888; font-weight:bold;">TODAY'S SALES</small>
            <h2 style="margin:10px 0; color:#2ecc71; font-size: 22px;">৳ <?php echo number_format($summary->sales, 2); ?></h2>
        </div>
        <div class="stat-card" style="border-color:#3498db;">
            <small style="color:#888; font-weight:bold;">TODAY'S ORDERS</small>
            <h2 style="margin:10px 0; color:#3498db; font-size: 22px;"><?php echo $summary->orders; ?></h2>
        </div>
        <div class="stat-card" style="border-color:#f1c40f;">
            <small style="color:#888; font-weight:bold;">AVG ORDER VALUE</small>
            <h2 style="margin:10px 0; color:#f39c12; font-size: 22px;">৳ <?php echo number_format($summary->avg_value, 2); ?></h2>
        </div>
    </div>

    <!-- ৩. মান্থলি সেলস ওভারভিউ -->
    <div class="bottom-grid">
        <div class="chart-container">
            <h3 style="margin-top:0; font-size:16px;">Monthly Sales Overview</h3>
            <div style="width: 100%; overflow: hidden;">
                <canvas id="monthlyChart" style="max-width: 100% !important; height:450px"></canvas>
            </div>
        </div>
        <div class="chart-container">
            <h3 style="margin-top:0; font-size:16px;">Staff Performance</h3>
            <canvas id="staffChart"></canvas>
        </div>
    </div>

    <!-- ৪. নিচের দুই কলামের সেকশন -->
    <div class="bottom-grid">
        <!-- <div style="display:grid; gap:20px;"> -->
            <!-- Payment Methods -->
            <div class="chart-container">
                <h3 style="margin-top:0; font-size:16px;">Payment Methods</h3>
                <div style="max-width:400px; margin:auto;"><canvas id="payChart"></canvas></div>
            </div>

            <!-- Top Selling Items -->
            <div class="chart-container">
                <h3 style="margin-top:0; font-size:16px;">Top Selling Items</h3>
                <ul style="padding:0; list-style:none; margin:0;">
                    <?php foreach($top_items as $item): ?>
                        <li style="padding:10px 0; border-bottom:1px solid #eee; display:flex; justify-content:space-between; font-size:13px;">
                            <span><?php echo $item->item_name; ?></span>
                            <span style="font-weight:bold; color:#2ecc71;"><?php echo $item->qty; ?> sold</span>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <!-- </div> -->

    </div>
<!-- </div> -->

<script>
// কমন অপশন যা সব চার্টে কাজ করবে
const commonOptions = {
    responsive: true,
    maintainAspectRatio: false, // এটি খুব গুরুত্বপূর্ণ রেসপনসিভ এর জন্য
    plugins: {
        legend: {
            position: 'bottom', // লেজেন্ড নিচে থাকলে মোবাইলে জায়গা বাঁচে
        }
    }
};

new Chart(document.getElementById('monthlyChart'), {
    type: 'line',
    data: {
        labels: <?php echo json_encode(array_column($monthly_chart, 'date')); ?>,
        datasets: [{ 
            label: 'Sales', 
            data: <?php echo json_encode(array_column($monthly_chart, 'total')); ?>, 
            borderColor: '#2ecc71', 
            backgroundColor: 'rgba(46, 204, 113, 0.1)', 
            fill: true, 
            tension: 0.4 
        }]
    },
    options: commonOptions // এখানে অপশন ব্যবহার করা হয়েছে
});

new Chart(document.getElementById('staffChart'), {
    type: 'bar',
    data: {
        labels: <?php echo json_encode(array_column($staff_data, 'display_name')); ?>,
        datasets: [{ 
            label: 'Sales', 
            data: <?php echo json_encode(array_column($staff_data, 'total')); ?>, 
            backgroundColor: '#3498db' 
        }]
    },
    options: commonOptions
});

new Chart(document.getElementById('payChart'), {
    type: 'doughnut',
    data: {
        labels: <?php echo json_encode(array_column($payment_data, 'payment_method')); ?>,
        datasets: [{ 
            data: <?php echo json_encode(array_column($payment_data, 'count')); ?>, 
            backgroundColor: ['#f1c40f', '#e67e22', '#e74c3c', '#9b59b6'] 
        }]
    },
    options: commonOptions
});
</script>