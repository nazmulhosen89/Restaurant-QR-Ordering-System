<?php if(!empty($report_data)): 
    // টোটাল ক্যালকুলেশন ভেরিয়েবল
    $grand_total_qty = 0;
    $grand_total_revenue = 0;
?>
    <!-- রিপোর্ট অ্যাকশন বাটন -->
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
        <h3 style="margin:0; font-size:16px; color:#333;">Filter Results</h3>
        
        <div class="report-actions">
            <button onclick="printReport()" style="background: #3498db; color: white; border: none; padding: 7px 15px; border-radius: 4px; cursor: pointer; font-size: 12px; margin-right: 5px;">
                Print
            </button>
            <button onclick="exportToExcel('sales-report-table')" style="background: #27ae60; color: white; border: none; padding: 7px 15px; border-radius: 4px; cursor: pointer; font-size: 12px;">
                Export Excel
            </button>
        </div>
    </div>

    <div id="print-area">
        <table id="sales-report-table" class="qrrs-report-table" style="width: 100%; border-collapse: collapse; font-size: 13px; background: #fff;">
            <thead>
                <tr style="background: #e6f7ef; color: #2ecc71; text-align: left;">
                    <th style="padding: 12px; border-bottom: 2px solid #ddd;">Food Item</th>
                    <th style="padding: 12px; border-bottom: 2px solid #ddd;">Quantity Sold</th>
                    <th style="padding: 12px; border-bottom: 2px solid #ddd;">Total Revenue</th>
                    <th style="padding: 12px; border-bottom: 2px solid #ddd;">Avg. Price</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($report_data as $row): 
                    // যোগফল বের করা
                    $grand_total_qty += $row->total_qty;
                    $grand_total_revenue += $row->total_revenue;
                ?>
                <tr style="border-bottom: 1px solid #eee;">
                    <td style="padding: 12px;"><?php echo esc_html($row->item_name); ?></td>
                    <td style="padding: 12px; font-weight: bold; color: #2ecc71;"><?php echo esc_html($row->total_qty); ?></td>
                    <td style="padding: 12px;">৳ <?php echo number_format($row->total_revenue, 2); ?></td>
                    <td style="padding: 12px;">৳ <?php echo number_format($row->avg_price, 2); ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
            
            <!-- টোটাল ক্যালকুলেশন ফুট এরিয়া -->
            <tfoot style="background: #f9f9f9; font-weight: bold; border-top: 2px solid #2ecc71;">
                <tr>
                    <td style="padding: 12px; text-align: right;">GRAND TOTAL:</td>
                    <td style="padding: 12px; color: #2ecc71;"><?php echo $grand_total_qty; ?> Items</td>
                    <td style="padding: 12px; color: #2ecc71;">৳ <?php echo number_format($grand_total_revenue, 2); ?></td>
                    <td style="padding: 12px;">-</td>
                </tr>
            </tfoot>
        </table>
    </div>
<?php else: ?>
    <div style="text-align: center; padding: 50px;">
        <p style="color: #888;">No data found for the selected range.</p>
    </div>
<?php endif; ?>