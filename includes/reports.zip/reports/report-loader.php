<?php
include_once(__DIR__ . '/report-functions.php');


// handle_qrrs_generate_sales_report ফাংশনের ভেতর:
$date_range = sanitize_text_field($_POST['date_range']); // এটি "2026-05-01 to 2026-05-02" ফরম্যাটে থাকে

// টেবিল ফাইলগুলো ইনক্লুড করার আগে এই ভেরিয়েবলটি পাস হবে
include QRRS_PATH . 'includes/reports/report-sales-general-table.php';

if(isset($_POST['type'])) {
    $type = $_POST['type'];

    if($type == 'dashboard') {
        include('report-main-dash.php');
    } elseif($type == 'sales') {
        include('report-sales-ui.php');
    } elseif($type == 'generate_sales_table') {
        // ফিল্টার ভ্যালুগুলো রিসিভ করা
        $date_range = $_POST['date_range']; // উদা: "2023-10-01 to 2023-10-31"
        $dates = explode(' to ', $date_range);
        $start = $dates[0];
        $end = isset($dates[1]) ? $dates[1] : $dates[0];
        $category = $_POST['category'];

        $report_data = get_qrrs_item_wise_sales($start, $end, $category);
        include('report-sales-table-part.php'); // টেবিলের ডিজাইন ফাইল
    }
}