<?php
// reports.php
// এখানে কোনো ফাংশন কল করার দরকার নেই, শুধু ডিজাইন থাকবে
?>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
<script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>

<!-- PDF জেনারেট করার জন্য -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>
<!-- Excel জেনারেট করার জন্য -->
<script src="https://cdn.jsdelivr.net/gh/linways/table-to-excel@v1.0.4/dist/tableToExcel.js"></script>
<style>
    /* আপনার আগের CSS এখানে থাকবে */
    .qrrs-report-main { max-width: 100%; background: #f8f9fa; padding: 15px; border-radius: 10px; font-family: 'Segoe UI', Tahoma, sans-serif; }
    .report-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(140px, 1fr)); gap: 10px; margin-bottom: 25px; }
    .report-block { background: #fff; padding: 15px 5px; border-radius: 8px; border: 1px solid #ddd; text-align: center; cursor: pointer; font-weight: 600; font-size: 13px; color: #444; transition: 0.3s; }
    .report-block.active, .report-block:hover { border-color: #2ecc71; background: #f9fffb; color: #2ecc71; }

@media print {
    .no-print, .report-actions, .sidebar, .report-grid {
        display: none !important;
    }
    .qrrs-report-main {
        background: none !important;
        padding: 0 !important;
    }
}

</style>

<div class="qrrs-report-main">
    <!-- ১. টপ মেনু ব্লকস -->
    <div class="report-grid">
        <div class="report-block active" data-target="dashboard">Dashboard</div>
        <div class="report-block" data-target="sales">Sales Report</div>
        <div class="report-block" data-target="order">Order Report</div>
        <div class="report-block" data-target="item">Item Performance</div>
        <div class="report-block" data-target="kitchen">Kitchen/KOT</div>
        <div class="report-block" data-target="staff">Staff Report</div>
        <div class="report-block" data-target="payment">Payment Report</div>        
        <div class="report-block" data-target="vat_sc">VAT/Service</div>
    </div>

    <!-- ২. এখানে ডাইনামিক কন্টেন্ট লোড হবে -->
    <div id="dynamic-report-content">
        <!-- পেজ লোড হলে প্রথমে মেইন ড্যাশবোর্ড দেখাবে -->
        <?php include('report-main-dash.php'); ?>
    </div>
</div>

<script>
jQuery(document).ready(function($) {
    // রেস্টুরেন্ট সিলেক্টর ড্রপডাউনটি ধরুন (আপনার HTML আইডি অনুযায়ী পরিবর্তন হতে পারে)
    // স্ক্রিনশট অনুযায়ী এটি সম্ভবত header এ আছে
    $(document).on('change', '.restaurant-selector select, #qrrs_res_selector', function() {
        // বর্তমানে কোন রিপোর্টটি একটিভ আছে তা দেখা
        var activeTarget = $('.report-block.active').data('target');
        
        if(activeTarget) {
            // একটিভ রিপোর্ট ব্লকটি ম্যানুয়ালি ক্লিক ট্রিগার করা যাতে ডাটা রিফ্রেশ হয়
            $('.report-block.active').trigger('click');
        }
    });

    // আপনার বিদ্যমান AJAX লোডার ফাংশন (যাতে কোন পরিবর্তন দরকার নেই)
    $('.report-block').on('click', function() {
        var target = $(this).data('target');
        $('.report-block').removeClass('active');
        $(this).addClass('active');

        $('#dynamic-report-content').html('<p style="text-align:center; margin-top:50px;">Loading Report... Please wait.</p>');

        $.ajax({
            url: qrrs_vars.ajax_url,
            type: 'POST',
            data: {
                action: 'qrrs_load_report_section',
                security: qrrs_vars.nonce,
                report_type: target
            },
            success: function(response) {
                if (response.success) {
                    $('#dynamic-report-content').html(response.data);
                }
            }
        });
    });
});
</script>