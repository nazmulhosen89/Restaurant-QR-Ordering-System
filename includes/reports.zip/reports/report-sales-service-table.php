<?php if(!empty($report_data)): ?>
    <h3 style="border-bottom: 2px solid #eee; padding-bottom: 10px;">Service Wise Performance</h3>
    
    <?php 
    $services = [
        'dine_in'   => ['label' => 'Dine-In', 'color' => '#3498db'],
        'takeaway'  => ['label' => 'Takeaway', 'color' => '#e67e22'],
        'delivery'  => ['label' => 'Delivery', 'color' => '#9b59b6']
    ];

    foreach ($services as $key => $info): 
        // লজিক অনুযায়ী ডেটা ফিল্টার করা
        $current_data = array_filter($report_data, function($item) use ($key) {
            if($key == 'dine_in') return ($item->table_name != 'Take Out' && $item->table_name != 'Delivery');
            if($key == 'takeaway') return ($item->table_name == 'Take Out');
            if($key == 'delivery') return ($item->table_name == 'Delivery');
            return false;
        });

        $service_total = 0;
    ?>
        <div style="margin-top: 30px; background: #fff; padding: 15px; border-radius: 10px; box-shadow: 0 2px 5px rgba(0,0,0,0.05);">
            <h4 style="color: <?php echo $info['color']; ?>; margin-bottom: 10px;"><?php echo $info['label']; ?> Orders</h4>
            <table class="qrrs-report-table" style="width: 100%; border-collapse: collapse; font-size: 13px;">
                <thead>
                    <tr style="background: #f8f9fa; text-align: left;">
                        <th style="padding: 10px;">Invoice #</th>
                        <th style="padding: 10px;">Table Name</th>
                        <th style="padding: 10px;">Total Items</th>
                        <th style="padding: 10px;">Final Amount</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if($current_data): foreach($current_data as $order): 
                        $service_total += $order->final_total;
                    ?>
                        <tr style="border-bottom: 1px solid #eee;">
                            <td style="padding: 10px;">#<?php echo $order->id; ?></td>
                            <td style="padding: 10px;"><?php echo $order->table_name; ?></td>
                            <td style="padding: 10px;"><?php echo $order->total_items; ?> Qty</td>
                            <td style="padding: 10px; font-weight:bold;">৳ <?php echo number_format($order->final_total, 2); ?></td>
                        </tr>
                    <?php endforeach; else: ?>
                        <tr><td colspan="4" style="padding: 15px; text-align: center; color: #ccc;">No <?php echo $info['label']; ?> orders found.</td></tr>
                    <?php endif; ?>
                </tbody>
                <tfoot style="background: #fffcf5; font-weight: bold; border-top: 2px solid <?php echo $info['color']; ?>;">
                    <tr>
                        <td colspan="3" style="padding: 10px; text-align: right;">Total <?php echo $info['label']; ?> Sales:</td>
                        <td style="padding: 10px; color: <?php echo $info['color']; ?>;">৳ <?php echo number_format($service_total, 2); ?></td>
                    </tr>
                </tfoot>
            </table>
        </div>
    <?php endforeach; ?>
<?php endif; ?>