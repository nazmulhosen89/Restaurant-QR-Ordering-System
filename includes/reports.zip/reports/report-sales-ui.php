<!-- report-sales-ui.php -->
<div class="sales-layout" style="display: flex; gap: 20px; align-items: flex-start;">
    
    <!-- Left Sidebar -->
    <div class="sidebar" style="width: 280px; background: #fff; padding: 20px; border-radius: 12px; box-shadow: 0 4px 10px rgba(0,0,0,0.05);">
        <h3 style="font-size: 16px; margin-bottom: 20px;">Sales Filters</h3>
        
        <div class="filter-group" style="margin-bottom: 15px;">
            <label style="display:block; font-size:12px; font-weight:bold; color:#666;">REPORT TYPE</label>
            <select id="rtype" style="width:100%; padding:8px; border:1px solid #ddd; border-radius:6px;">
                <option value="sales">Sales Report</option>
                <option value="item_wise">Item-wise Sales Report</option>
                <option value="category_wise">Category-wise Sales Report</option>
                <option value="service">Dine-in vs Takeaway vs Delivery</option>
            </select>
        </div>

        <div class="filter-group" style="margin-bottom: 15px;">
            <label style="display:block; font-size:12px; font-weight:bold; color:#666;">DATE RANGE</label>
            <input type="text" id="sales_date" placeholder="Select Dates" style="width:100%; padding:8px; border:1px solid #ddd; border-radius:6px;">
        </div>

        <div class="filter-group" style="margin-bottom: 20px;">
            <label style="display:block; font-size:12px; font-weight:bold; color:#666;">CATEGORY</label>
            <select id="scat" style="width:100%; padding:8px; border:1px solid #ddd; border-radius:6px;">
                <option value="all">All Category</option>
                <!-- ক্যাটাগরি লুপ এখানে হবে -->
            </select>
        </div>

        <!-- এখানে ID="generate_report_btn" যোগ করা হয়েছে -->
        <button id="generate_report_btn" style="width:100%; background:#2ecc71; color:white; border:none; padding:12px; border-radius:6px; font-weight:bold; cursor:pointer;">Generate Report</button>
    </div>

    <!-- Right Main Section (ID="main-report-view" যোগ করা হয়েছে) -->
    <div id="main-report-view" class="main-report-view" style="flex: 1; background: #fff; padding: 25px; border-radius: 12px; box-shadow: 0 4px 10px rgba(0,0,0,0.05); min-height: 500px;">
        <div style="text-align:center; color:#ccc; margin-top:100px;">
             <h2>Sales Analytics</h2>
             <!-- <p>ফিল্টার সিলেক্ট করে রিপোর্ট জেনারেট করুন</p> -->
        </div>
    </div>
</div>

<script>
jQuery(document).ready(function($) {
    // ১. ক্যালেন্ডার সেটাআপ
    if (typeof flatpickr !== 'undefined') {
        flatpickr("#sales_date", { 
            mode: "range", 
            dateFormat: "Y-m-d" 
        });
    }

    // ২. জেনারেট বাটন ক্লিক
    $('#generate_report_btn').on('click', function(e) {
        e.preventDefault();

        var dateRange = $('#sales_date').val();
        var category  = $('#scat').val();
        var reportType = $('#rtype').val();

        if(!dateRange) {
            alert('Please select a date range!');
            return;
        }

        // কন্টেইনার ক্লিয়ার করে লোডিং দেখানো
        $('#main-report-view').html('<p style="text-align:center; margin-top:50px;">Generating Report... Please wait.</p>');

        // AJAX কল
        $.ajax({
            url: qrrs_vars.ajax_url, 
            type: 'POST',
            data: {
                action: 'qrrs_generate_sales_report', // এটি আপনার প্লাগইন এর Action
                security: qrrs_vars.nonce,           
                date_range: dateRange,
                category: category,
                report_type: reportType
            },
            success: function(response) {
                // response.data তেই মূলত আপনার PHP থেকে আসা 'report-sales-table-part.php' এর টেবিল HTML থাকবে
                if (response.success) {
                    $('#main-report-view').html(response.data);
                } else {
                    $('#main-report-view').html('<p style="color:red; text-align:center;">Error: ' + response.data + '</p>');
                }
            },
            error: function(xhr, status, error) {
                $('#main-report-view').html('<p style="color:red; text-align:center;">AJAX Error: Something went wrong!</p>');
            }
        });
    });
    
});

// ১. আপডেট করা প্রিন্ট ফাংশন
window.printReport = function() {
    const header = document.getElementById('dynamic-print-header').innerHTML;
    const footer = document.getElementById('dynamic-print-footer').innerHTML;
    const table = document.getElementById('report-print-area').innerHTML;
    
    const originalContent = document.body.innerHTML;
    
    // হেডার, টেবিল এবং ফুটার একসাথে জোড়া লাগানো
    document.body.innerHTML = `
        <html>
            <head><title>Print Report</title></head>
            <body style="padding: 20px; font-family: sans-serif;">
                ${header}
                <div style="margin-top: 20px;">${table}</div>
                <div style="margin-top: 30px;">${footer}</div>
            </body>
        </html>`;
    
    window.print();
    window.location.reload(); 
}

// ২. আপডেট করা PDF ফাংশন (পুরো পিডিএফ পাওয়ার জন্য)
jQuery(document).on('click', '#btnExportPDF', function() {
    const header = document.getElementById('dynamic-print-header').innerHTML;
    const footer = document.getElementById('dynamic-print-footer').innerHTML;
    const table = document.getElementById('report-print-area').innerHTML;

    // পিডিএফ এর জন্য নতুন এলিমেন্ট তৈরি
    const element = document.createElement('div');
    element.innerHTML = `<div>${header}</div><div style="margin: 20px 0;">${table}</div><div>${footer}</div>`;

    const opt = {
        margin:       [0.5, 0.3], // [top, left/right]
        filename:     'Restaurant_Report.pdf',
        image:        { type: 'jpeg', quality: 0.98 },
        html2canvas:  { 
            scale: 2, 
            useCORS: true, 
            scrollY: 0, 
            scrollX: 0 
        },
        jsPDF:        { unit: 'in', format: 'letter', orientation: 'portrait' },
        pagebreak:    { mode: ['avoid-all', 'css', 'legacy'] } // টেবিল যাতে মাঝখানে না কাটে
    };

    html2pdf().set(opt).from(element).save();
});

// 3. এক্সেল এক্সপোর্ট (ডাইনামিক বাটনের জন্য ইভেন্ট ডেলিগেশন)
jQuery(document).on('click', '#btnExportExcel', function() {
    let table = document.querySelector("#report-print-area table");
    if(table) {
        TableToExcel.convert(table, {
            name: "Sales_Report.xlsx",
            sheet: { name: "Sheet 1" }
        });
    } else {
        alert("Table not found!");
    }
});
</script>